clear all;
close all;

Run = {'Run31','Run32','Run33','Run34'};
Stage = [4    ,5      , 5     , 6];

Genes = [];
for j=1:length(Run)
    Genes_per_stage = func_combine_Genes(Run{j},Stage(j));
    Genes = unique([Genes,Genes_per_stage]);
end
save('Genes.mat','Genes');