PHATE for Matlab
----------------

#### phate.m -- main function for running PHATE in Matlab

'help PHATE' for documentation

run_phate_EB.m -- run PHATE on embryoid body data

run_phate_tree.m -- run PHATE on tree data

run_phate_DLA_tree.m -- run PHATE on DLA tree data

run_phate_mESC.m -- run PHATE on mESC data
