function [Accuracy,ValErr,Momentum,L2Reg,InitLR] = func_TrainModel(norm_sel,UsePrevMod)
%Train Model (training DeepInsight-FS)


% run Prepare_Data.m %TCGA RNA-seq data will be prepared using tSNE algorithm
% see Prepare_Data.m for details

curr_dir = pwd;
addpath(curr_dir);

Parm.fid=fopen('Results.txt','a+');
Parm.UsePreviousModel = 0;

[upm,Mo,Init,Reg] = func_UsePreviousModel(UsePrevMod); %UsePrevMod 'y for yes and 'n' for no
Parm.UsePreviousModel = upm; Parm.Momentum = Mo; Parm.InitialLearnRate = Init; Parm.L2Regularization = Reg;


if norm_sel==2
[model, Norm]  = DeepInsight_train_CAM(Parm,2); % if you want to use Norm 2 only
elseif norm_sel==1
	[model, Norm] = DeepInsight_train_CAM(Parm,1);
else
[model, Norm]  = DeepInsight_train_CAM(Parm); % best norm will be determined by the algorithm
end

if Norm==1
    Data = load('Out1.mat');
else
    Data = load('Out2.mat');
end
if size(Data.XTrain,3)<3
    Data.XTest = cat(3,Data.XTest,Data.XTest,Data.XTest);
end
Data = rmfield(Data,'XTrain');
Data = rmfield(Data,'YTrain');
Data = rmfield(Data,'XValidation');
Data = rmfield(Data,'YValidation');

Accuracy = DeepInsight_test_CAM(Data,model)

model.Norm=Norm;
save('model.mat','-struct','model','-v7.3');
fclose(Parm.fid);
ValErr = model.valError;
cd DeepResults	
f=load(model.fileName);
cd ..
Momentum = f.options.Momentum;
L2Reg = f.options.L2Regularization;
InitLR = f.options.InitialLearnRate;


