clear all;
close all;

%Parm.fid=fopen('Results.txt','a+');
Parm.Method = ['tsne'];%['tSNE']; % 1) tSNE 2) kpca or 3) pca 4) umap 5) phate
Parm.Dist = 'cosine';%'hamming'; % For tSNE only 1) Mahalanobis 2) cosine 3) euclidean 4) chebychev 5) correlation 6) hamming (default: cosine)
Parm.Max_Px_Size = 227; %inf; 227 for SqueezeNet
Parm.MPS_Fix=1;
%Parm.MPS_Fix = 1; % if this val is 1 then screen will be 
                  % Max_Px_Size x Max_Px_Size (e.g. 227x227), otherwise 
                  % automatically decided by the distribution of the input data.
                  
Parm.ValidRatio = 0.1; % ratio of validation data/Training data
Parm.Seed = 108; % random seed to distribute training and validation sets
Parm.Norm = 2; % Select '1' for Norm-1, '2' for Norm-2 and '0' for automatically select the best Norm (either 1 or 2).
Parm.FileRun = 'Run1';
Parm.SnowFall = 0;%1; % Put 1 if you want to use SnowFall compression algorithm
Parm.Threshold = 0.6; %CAM threshold [0,1]
Parm.DesiredGenes = 1200;%1200;%1200;
Parm.UsePrevModel = 'n'; % 'y' for yes and 'n' for no (for CNN). For 'y' the hyperparameter of previous stages will be used.
Parm.SaveModels = 'y'; % 'y' for saving models or 'n' for not saving
Parm.Stage=2; % '1', '2', '3', '4', '5' depending upon which stage of DeepInsight-FS to run.
Parm.GenePerSample=0; %do not find gene/feature set per sample. If '1' then find

%Define where you want to store the model and FIGS
curr_dir=pwd;
FIGS_path = [curr_dir,'/FIGS/'];
Models_path = [curr_dir,'/Models/'];
Parm.PATH{1} =  FIGS_path; %Store figures in this folder
Parm.PATH{2} = Models_path; % Store model in this folder

fid2 = fopen('DeepFeature_Results.txt','a+');
fprintf(fid2,'%s',Parm.FileRun);
fprintf(fid2,'\n');
fprintf(fid2,'SnowFall: %d\n',Parm.SnowFall);
fprintf(fid2,'Method: %s\n',Parm.Method);
if any(strcmp('Dist',fieldnames(Parm)))==1
    fprintf(fid2,'Distance: %s\n',Parm.Dist);
else
    fprintf(fid2,'Distance is not applicable or Deafult\n');
end
fprintf(fid2,'Threshold: %6.2f\n',Parm.Threshold);
fprintf(fid2,'Use Previous Model: %s\n',Parm.UsePrevModel);

Glen=inf; 

while (Glen > Parm.DesiredGenes) & (Parm.Stage < 7)
    close all;
    fprintf(fid2,'Stage %d Begins\n',Parm.Stage);
    fprintf('Stage %d Begins\n',Parm.Stage);
    display('Starting Data preparation by DeepInsight');
    [InputSz1,InputSz2,Init_dim] = func_Prepare_Data(Parm);
    
    fprintf('Input Size 1 x Input Size 2: %d x %d\n',InputSz1,InputSz2);
    fprintf(fid2,'Input Size 1 x Input Size 2: %d x %d\n',InputSz1,InputSz2);
    if Parm.Stage<=2
        fprintf(fid2,'Initial Dimension: %d\n',Init_dim);
    end
    display('Data preparation ends');
    fprintf('\n');

display('Training model begins');
[Accuracy(Parm.Stage),ValErr(Parm.Stage),Momentum(Parm.Stage),L2Reg(Parm.Stage),InitLR(Parm.Stage)] = func_TrainModel(Parm.Norm, Parm.UsePrevModel);
fprintf('Stage: %d; Test Accuracy: %6.4f; ValErr: %4.4f; \n',Parm.Stage,Accuracy(Parm.Stage),ValErr(Parm.Stage));
fprintf('Momentum: %g; L2Regularization: %g; InitLearnRate: %g\n',Momentum(Parm.Stage),L2Reg(Parm.Stage),InitLR(Parm.Stage));
fprintf(fid2,'Stage: %d; Test Accuracy: %6.4f; ValErro: %4.4f; \n',Parm.Stage,Accuracy(Parm.Stage),ValErr(Parm.Stage));
fprintf(fid2,'Momentum: %g; L2Regularization: %g; InitLearnRate: %g\n',Momentum(Parm.Stage),L2Reg(Parm.Stage),InitLR(Parm.Stage));
display('Training model ends');
fprintf('\n');


display('Feature selection begins');
[Genes,Genes_compressed,G]= func_FeatureSelection_CAM(Parm);
G
Glen=length(Genes);
Glen_comp = length(Genes_compressed);
fprintf('#Genes = %d; #Genes_compressed = %d\n',Glen,Glen_comp);
fprintf(fid2,'#Genes = %d; #Genes_compressed = %d\n',Glen,Glen_comp);
display('Feature selection ends');
fprintf('Stage %d Ends\n',Parm.Stage);
fprintf(fid2,'Stage %d Ends\n\n',Parm.Stage);

Parm.Stage=Parm.Stage+1;
end
